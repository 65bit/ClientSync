FastDelegate
============

C++11 version of Don Clugston's FastDelegate library, by Ceniza.

This is the unofficial V2 version which in my humbled opinion is much better. Though performance wise I'm not sure if there're any difference.


Original source/link
--------------------
 * https://sites.google.com/site/ceniza666/cpp
 * http://www.codeproject.com/Messages/4489700/Cplusplus11.aspx


Credits
-------
 * Don Clugston
 * Paúl Jiménez(Ceniza)


Disclaimer
----------
This program is distributed in the hope that it will be useful. It is provided 'as-is', without any expressor implied warranty. In no event will the author/s and/or distributor/s be held liable for any damages arising from the use of this software.
