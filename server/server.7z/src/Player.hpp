#pragma once

#include <vector>
#include <algorithm>
#include <set>

#include "CommonTypes.hpp"

struct Vec2
{
    float x{ 0.0f };
    float y{ 0.0f };
    
    Vec2() = default;
    
    Vec2(float _x, float _y)
    : x(_x)
    , y(_y)
    {
        
    }
    
    Vec2 operator + (const Vec2& _vec)
    {
        return {x + _vec.x, y + _vec.y};
    }
};

class Player
{
    using ClientFrames = std::set<common::ClientFrame>;
    using ServerFrames = std::set<common::ServerFrame>;

public:
    Player(const common::ID& _id)
        : m_id(_id)
    {

    }

	void pushClientFrames(const ClientFrames& _frames)
	{
		m_clientFrames.insert(_frames.begin(), _frames.end());
	}

	void pushServerFrames(const ServerFrames& _frames)
	{
		m_serverFrames.insert(_frames.begin(), _frames.end());
	}

	ServerFrames&& popServerFrames()
	{
		return std::move(m_serverFrames);
	}

	common::ClientFrame popNextClientFrame()
	{
		if (!hasNextClientFrame())
		{
			return{ common::InvalidID };
		}

		const auto frame = *m_clientFrames.begin();
		m_clientFrames.erase(m_clientFrames.begin()); //#TODO: Optimize this erase

		return frame;
	}

	bool hasNextClientFrame() const
	{
		return !m_clientFrames.empty();
	}

	common::ID getID() const
	{
		return m_id;
	}
    
	Vec2 getPosition() const
	{
		return m_pos;
	}

private:
    const common::ID m_id;
    
    ClientFrames m_clientFrames;
    ServerFrames m_serverFrames;
    
    Vec2 m_pos;
};
